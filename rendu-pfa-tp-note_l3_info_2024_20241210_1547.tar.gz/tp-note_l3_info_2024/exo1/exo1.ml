type movie =
  { id : int; title : string; year : int; runtime : int; rank : int }

(* Question 1: lecture d'une ligne *)
let parse_movie str = 
  let liste = String.split_on_char ';' str in
  let id = int_of_string (List.nth liste  0) in 
  let title = List.nth liste 1 in 
  let year = int_of_string  (List.nth liste 2) in 
  let runtime = int_of_string  (List.nth liste 3) in 
  let rank = int_of_string  (List.nth liste 4) in 
  { id ;title ; year ; runtime ;rank } 

(* Fin Question 1 *)


(* Question 2: Top_k *)
let top_k k pred movies = 
  let rec aux l n = 
    match l,n with 
    | _ , 0 -> []
    | [],n ->  movies
    | film :: tail , n-> 
      if pred film then 
        film :: aux tail (n-1) 
    else
      aux tail n 
  in aux movies k 

(* Fin Question 2 *)

(* Question 3: Group by *)
let group_by f movies = 
  let cache = Hashtbl.create 10 in 
  let rec aux l = 
    match l with 
    [] -> ()
    | film :: tail -> 
      let opt = Hashtbl.find_opt cache (f film ) in 
      match opt with 
      | None -> 
        Hashtbl.add cache (f film ) (1) ;
         aux tail 
      | Some v -> 
        Hashtbl.replace cache (f film) (v+1) 
        ; aux tail 
    in aux movies ; 
    Hashtbl.fold (fun  key v acc -> (key , v ) :: acc ) cache [] 


(* Fin Question 3 *)


(* Code fourni pour les tests, vos tests peuvent aller en fin de fichier. *)
let print_movie m =
  Printf.printf "%d;%s;%d;%d;%d\n"
    m.id m.title m.year m.runtime m.rank

let print_movies l = List.iter print_movie l

let input_lines file =
  Array.to_list (Arg.read_arg file)

let parse_file file =
  List.map parse_movie (input_lines file)

let movies = parse_file "movies.txt"
(* Si le chargement ci-dessus plante à cause de votre fonction
   parse_line, le remplacer par la définition suivante pour tester
   vos autres fonctions.

let movies = [
   {id = 2065; title = "The Treasure of the Sierra Madre"; year = 1948;
   runtime = 126; rank = 66};
   {id = 2115; title = "Million Dollar Baby"; year = 2004; runtime = 132;
   rank = 116};
   {id = 2089; title = "No Country for Old Men"; year = 2007; runtime = 122;
   rank = 90};
   {id = 2009; title = "Star Wars : Episode V - The Empire Strikes Back";
   year = 1980; runtime = 190; rank = 10};
   {id = 2070; title = "Singin' in the Rain"; year = 1952; runtime = 103;
   rank = 71};
   {id = 2175; title = "Kill Bill : Vol. 2"; year = 2004; runtime = 136;
   rank = 176};
   {id = 2169; title = "Rocky"; year = 1976; runtime = 119; rank = 170};
   {id = 2159; title = "In Bruges"; year = 2008; runtime = 107; rank = 160};
   {id = 2004; title = "The Good,the Bad and the Ugly"; year = 1966;
   runtime = 190; rank = 5}; ]

*)