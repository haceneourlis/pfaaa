#!/bin/sh

D=`basename "$(pwd)"`
if ! grep -q 'EMAIL: *[a-zA-Z0-9_.-]\+@[a-zA-Z0-9_.-]\+' infos.txt 
then
	echo 'Le fichier infos.txt ne contient pas de mail'
	exit 1
fi
cd ..
tar cfzv rendu-pfa-"$D"_"$(date +%Y%m%d_%H%M)".tar.gz "$D"
