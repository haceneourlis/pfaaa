(* Le type des AVL *)

module type COMPARABLE =
sig
  type t
  val compare : t -> t -> int
end

module Make (E : COMPARABLE)  =
struct

  open Abr
  (* rend visible le type tree du fichier abr.mli
     ainsi que la fonction merge. *)

  type t = E.t tree
  let empty = Leaf

  (* Question 1: singleton *)
  let singleton v n =

    if n <= 0 then 
      Leaf 
    else
      Node (0,empty ,v,n , empty) 

  (* Fin Question 1 *)

  (* Question 2: join *)
  let join t1 v n t2 = merge t1 (merge (singleton v n) t2)

  (* Fin Question 2 *)

  (* Question 3: add *)

  (* Ajout avec multiplicité dans un arbre binaire. *)
  (* Attention, la fonction add doit être récursive. *)
  let rec add v n t = 
    match t with 
    Leaf -> singleton v n  
    | Node ( h , l , current , occ, r ) 
    ->
      if current = v then 
        Node (h , l , current , occ + n , r )
    else 
      if current < v then 
        join l current occ (add v n r )
      else
        join (add v n l ) current occ r


  (* Fin Question 3 *)

  (* Fonction utilisée pour tester *)
  let rec count e t =
    match t with
      Leaf -> 0
    | Node (_, l, x, nx, r) ->
      let c = E.compare e x in
      if c < 0 then count e l
      else if c > 0 then count e r
      else nx

end

module IMSet = Make(Int)
let test () =
  let set1 = IMSet.(add 10 3 (add 20 4 (add 30 8 IMSet.empty))) in
  let set2 = IMSet.add 42 (-1) (IMSet.(add 10 7 (add 30 (-10) set1))) in
  assert (IMSet.count 10 set1 = 3);
  assert (IMSet.count 30 set1 = 8);
  assert (IMSet.count 10 set2 = 13);
  assert (IMSet.count 30 set2 = 0);
  assert (IMSet.count 42 set2 = 0)


(* Décomenter la ligne ci-dessous pour tester. *)
let () = test ()