type 'a tree =
  | Leaf
  | Node of (int * 'a tree * 'a * int * 'a tree)

(* Les définitions auxiliaires ci-dessous ne sont pas à connaître.
   Elles permettent d'écrire merge ligne 67 puis de faire les questions.*)

let height t = match t with
    Leaf -> 0
  | Node (h, _, _, _, _) -> h

let node l v n r = Node (1+ max (height l) (height r), l, v, n, r)


let rotate_left t =
  match t with
  | Node (_, l, v, nl, Node (_, lr, vr, nr, rr)) -> node (node l v nl lr) vr nr rr
  | _ -> failwith "rotate_left"

let rotate_right t =
  match t with
  | Node (_, Node (_, ll, vl, nl, rl), v, nr, r) -> node ll vl nl (node rl v nr r)
  | _ -> failwith "rotate_right"

let rec join_avl_right l v nv r =
  match l with
  | Leaf -> failwith "impossible"
  | Node (_, ll, vl, nl, rl) ->
    if height rl <= height r + 1 then
      let new_r = node rl v nv r in
      if height new_r <= height ll + 1 then node ll vl nl new_r
      else rotate_left (node ll vl nl (rotate_right new_r))
    else
      let new_r = join_avl_right rl v nv r in
      let new_t = node ll vl nl new_r in
      if height new_r <= height ll + 1 then new_t else rotate_left new_t

let rec join_avl_left l v nv r =
  match r with
  | Leaf -> failwith "impossible"
  | Node (_, lr, vr, nr, rr) ->
    if height lr <= height l + 1 then
      let new_l = node l v nv lr in
      if height new_l <= height rr + 1 then node new_l vr nr rr
      else rotate_right (node (rotate_left new_l) vr nr rr)
    else
      let new_l = join_avl_left l v nv lr in
      let new_t = node new_l vr nr rr in
      if height new_l <= height rr + 1 then new_t else rotate_right new_t

let join_avl l v nv r =
  if height l > height r + 1 then join_avl_right l v nv r
  else if height r > height l + 1 then join_avl_left l v nv r
  else node l v nv r

let rec split_last t =
  match t with
    Leaf -> failwith "impossible"
  | Node (_, l, v, n, Leaf) -> l, (v, n)
  | Node (_, l, v, n, r) ->
    let r', p = split_last r in
    join_avl l v n r', p

let merge t1 t2 =
  match t1 with
    Leaf -> t2
  | _ -> let tl, (v, n) = split_last t1 in
    join_avl tl v n t2

