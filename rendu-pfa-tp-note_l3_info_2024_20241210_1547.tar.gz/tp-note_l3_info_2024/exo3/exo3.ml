(* le graphe de test *)
let graph = Hashtbl.create 16
let () =
  Hashtbl.add graph 0 [1;6];
  Hashtbl.add graph 1 [2];
  Hashtbl.add graph 2 [0;3];
  Hashtbl.add graph 3 [4];
  Hashtbl.add graph 4 [2];
  Hashtbl.add graph 5 [0];
  Hashtbl.add graph 6 [2]


(* Question 1 : liste des arrêtes *)

let get_edges graph v = 
  let n = Hashtbl.length graph in 
  if v >= 0 && v < n then 
    let liste_succ = Hashtbl.find graph v in 
    List.fold_left (fun acc e -> (v,e)::acc ) liste_succ [] 
  else
    []
    

(* Fin Question 1 *)

(* Question 2 : Nombre d'arrêtes *)

let count_edges graph = 
  let n = Hashtbl.length graph in
  let size = ref 0 in 
  (*en gros c'est juste la somme des taille des listes dans le hashmap *)
  for i = 0 to n - 1 do 
    size := !size + List.length (Hashtbl.find graph i)
  done ; 
  !size 


(* Fin question 2 *)

(* Question 3 *)
let eulerian f graph =
  let number_Nodes = Hashtbl.length graph in 
  let total_edges = count_edges graph in
  let rec loop v path n =
    if total_edges = n then
      f path 
    else
      let successeurs = Hashtbl.find graph v in 
      List.iter ( fun w -> 
        if not(List.mem (v,w) path )then 
           loop w ((v,w)::path) (n+1)
          ) successeurs
  in
  for i = 0 to number_Nodes - 1 do 
    loop i [] 0
  done 

(* Fin Question 3 *)

(* Code de test, ne pas modifier *)
let print_edge_list l =
  List.iter (fun (v,w) -> Printf.printf "(%d, %d); " v w) l;
  Printf.printf "\n"

let main () =
  eulerian print_edge_list graph

let () = main ()
